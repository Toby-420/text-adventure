<h1>The Room of the Locked Door</h1>
<h2>What is this?</h2>
<p>This is a text adventure game written entirely in C.</p>
<p>It uses pdcurses (Windows version of ncurses) to have multiple windows</p>
<p>There is ASCII art in one window which is a simulation of what the player would see. Currently, only 2 rooms have this</p>
<p>There are 3 rooms. 2 obvious, 1 hidden</p>
<h2>Who worked on this?</h2>
<p>Me and my Dad (who does not have a github account)</p>
<p>I did most of the programming, and my dad helped by providing lots of ideas, ASCII art, debugging help and cans of Sanpellegrino</p>
<h2>How often will updates be posted?</h2>
<p>Possibly every week, but I will try for at least 1 per month</p>
<h2>Where can I donate?</h2>
<p>I currently have no way for donations, and that is fine because having people use my software and talking about it to others is more than enough :)</p>
